var searchData=
[
  ['calculategradient_5fforcecontrol_5fspace_5fhm',['calculateGradient_forceControl_space_Hm',['../classgradient__calculator.html#a8381a8497dfe88bcb04ff40ce1e235e0',1,'gradient_calculator']]],
  ['calculategradient_5fforcecontrol_5fspace_5fhm_5fnot_5fparallel',['calculateGradient_forceControl_space_Hm_not_parallel',['../classgradient__calculator.html#a62952c354762514d88d70e323957fb34',1,'gradient_calculator']]],
  ['calculategradient_5fforcecontrol_5fspace_5fhm_5fplasma',['calculateGradient_forceControl_space_Hm_plasma',['../classgradient__calculator.html#a3a53b6132184c796ef3aca1e306e2211',1,'gradient_calculator']]]
];
