var searchData=
[
  ['get_5fstepdirection',['get_stepdirection',['../classstepdirection__controller.html#ab2d76b39009f8d6c0121288d79c42a9d',1,'stepdirection_controller']]],
  ['getvelocitymagnitudeparticle',['getVelocityMagnitudeParticle',['../classparticle.html#a4746319805ea7d18c4a3eac998b02043',1,'particle']]]
];
