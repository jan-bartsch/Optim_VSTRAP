var searchData=
[
  ['gradient_5fcalculator',['gradient_calculator',['../classgradient__calculator.html',1,'']]],
  ['gradient_5fvalidation',['gradient_validation',['../classgradient__validation.html',1,'']]]
];
