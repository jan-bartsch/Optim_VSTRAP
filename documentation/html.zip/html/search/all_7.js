var searchData=
[
  ['lara_20_20_2d_20_5fa_20monte_20car_2a_2al_2a_2ao_20framework_20for_20optim_2a_2aa_2a_2al_20cont_2a_2ar_2a_2aol_20of_20plasm_2a_2aa_2a_2a_5f',['LARA  - _A Monte Car**L**o framework for optim**A**l cont**R**ol of plasm**A**_',['../md__home_jan_Promotion_linuxPC_Optim_VSTRAP_README.html',1,'']]]
];
